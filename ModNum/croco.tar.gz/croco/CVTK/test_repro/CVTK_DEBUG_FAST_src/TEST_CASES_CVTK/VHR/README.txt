Dans ce repertoire on met les fichiers BENGUELA_VHR en cas
[ et on evite un repertoire vides qui peut etre commité ]

