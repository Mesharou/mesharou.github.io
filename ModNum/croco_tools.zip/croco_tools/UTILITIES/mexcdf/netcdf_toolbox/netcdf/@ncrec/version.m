function version(self)

% Version of 30-Apr-2003 11:16:19.

helpdlg(help(mfilename), 'ncrec')
